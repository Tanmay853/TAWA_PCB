#include <Arduino.h>
#include <AsyncTCP.h>
#include <AsyncWebSocket.h>

const char* ssid = "Shrey";
const char* password = "shrey2003";

AsyncWebServer server(80);
AsyncWebSocket ws("/ws");

bool isConnected = false;

const uint8_t TX_PIN = 17;  // UART TX pin
const uint8_t RX_PIN = 16;  // UART RX pin

String receivedData = "";

String rpi_send = "";

String send_data[5];

bool isUTF8(const char *str) {
    unsigned int i = 0;
    while (str[i]) {
        if ((str[i] & 0xC0) != 0x80)
            return true;
        i++;
    }
    return false;
}

void sendDataPeriodically() {
    // This function will be called periodically to send data
    static int counter = 0;

    // Convert the counter to a string
    String message = String(counter);

    // Send the message via WebSocket
    ws.textAll(receivedData.c_str());

    // Increment the counter for the next iteration
    counter++;
}

void handleWebSocketMessage(void *arg, uint8_t * payload, size_t length) {

    rpi_send = "";

    String message[100];
    int j=0;

    for (size_t i = 0; i < length; i++) {
        String temp = "";

        while(((char)payload[i] != ',') && i<length){
          temp += (char)payload[i];
          i+=1;
        }
        message[j] = (temp);

        Serial.println(message[j]);
        j++;
    }
    
    for(int i=0;i<j;i++){
      Serial.println(message[i]);
      rpi_send.concat(message[i]);
      rpi_send.concat(",");
    }

    Serial.println(rpi_send);
}

void setup() {
  Serial.begin(9600); // Start UART at baud rate 115200
  Serial1.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN); // Start UART1

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }

  Serial.println("WiFi connected");
  Serial.println(WiFi.localIP());

  ws.onEvent([](AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len){
    if (type == WS_EVT_CONNECT) {
        Serial.println("WebSocket client connected");
        isConnected = true; // Set the connection flag to true when a client connects
    } else if (type == WS_EVT_DISCONNECT) {
        Serial.println("WebSocket client disconnected");
        isConnected = false; // Set the connection flag to false when a client disconnects
    } else if (type == WS_EVT_DATA) {
        handleWebSocketMessage(arg, data, len);
    }
  });

  server.addHandler(&ws);
  server.begin();
}

void loop() {
  // Send data from ESP32 to Raspberry Pi Pico
  if(rpi_send !=""){
    Serial1.println(rpi_send);
    rpi_send = "";
  }
  

  // Receive data from Raspberry Pi Pico
  if (Serial1.available()) {
    receivedData = Serial1.readStringUntil('\n');

    // int j=0;

    // for(int i=0;i<receivedData.length();i++){
    //   String temp = "";

    //   while(receivedData[i] != ',' && i<receivedData.length()){
    //     temp += receivedData[i];
    //     i++;
    //   }

    //   send_data[j] = temp;
    //   j++;
    //   temp = "";

    // }

    // if(isUTF8)
    Serial.print("Received from Raspberry Pi Pico: ");
    Serial.println(receivedData);
    // Serial.println();
  }


  if(isConnected){
    sendDataPeriodically();
  }

  delay(1000);
}
